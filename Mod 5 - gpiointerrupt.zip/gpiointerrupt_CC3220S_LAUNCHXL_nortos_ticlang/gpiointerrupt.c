/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Student addition */
#include <ti/drivers/Timer.h>
#include <string.h>

typedef enum{
    IDLE,
    DOT,
    DASH,
    GAP,
    NEXT_SYMBOL,
    NEXT_LETTER,
    MESSAGE_COMPLETE
} MorseState;

typedef struct {
    uint32_t dotDuration;
    uint32_t dashDuration;
    uint32_t symbolGap;
    uint32_t letterGap;
    uint32_t messageGap;
} MorseCodeTiming;

MorseCodeTiming morseCodeTiming = {
    .dotDuration = 500000,
    .dashDuration = 1500000,
    .symbolGap = 500000,
    .letterGap = 1500000,
    .messageGap = 3500000,
};

MorseState currentState = DOT;
bool changeMessage = false;

void timerCallback(Timer_Handle myHandle, int_fast16_t status){

    static const char* sos = "... --- ...";
    static const char* ok = "--- .-";
    const char* currentPattern = sos; // Initially set to SOS pattern
    static int symbolIndex = 0; // Index to track current symbol
    char symbol = currentPattern[symbolIndex];
    char nextSymbol = currentPattern[++symbolIndex];

    switch (currentState) {
        case DOT:
            GPIO_write(CONFIG_GPIO_LED_1, 1); // Turn on red LED for dot
            Timer_setPeriod(myHandle, Timer_PERIOD_US, morseCodeTiming.dotDuration);
            currentState = GAP; // Move to gap after emitting the dot
            break;
        case DASH:
            GPIO_write(CONFIG_GPIO_LED_0, 1); // Turn on green LED for dash
            Timer_setPeriod(myHandle, Timer_PERIOD_US, morseCodeTiming.dashDuration);
            currentState = GAP; // Move to gap after emitting the dash
            break;
        case GAP:
            GPIO_write(CONFIG_GPIO_LED_0, 0); // Ensure LEDs are off during gaps
            GPIO_write(CONFIG_GPIO_LED_1, 0);
            if(symbolIndex >= strlen(currentPattern)) {
                currentState = MESSAGE_COMPLETE;
            }
            else {
                if(nextSymbol == '.' || nextSymbol == '-') {
                    currentState = NEXT_SYMBOL;
                } else if(nextSymbol == ' ') {
                     currentState = NEXT_LETTER;
                }
            }
            break;
        case NEXT_SYMBOL:
            Timer_setPeriod(myHandle, Timer_PERIOD_US, morseCodeTiming.symbolGap);
            if(nextSymbol == '.') {
                currentState = DOT;
            }
            else if(nextSymbol == '-') {
                currentState = DASH;
            }
            symbolIndex++;
            break;
        case NEXT_LETTER:
            Timer_setPeriod(myHandle, Timer_PERIOD_US, morseCodeTiming.letterGap);
            if(nextSymbol == '.') {
                currentState = DOT;
            }
            else if(nextSymbol == '-') {
                currentState = DASH;
            }
            symbolIndex++;
            break;
        case MESSAGE_COMPLETE:
            Timer_setPeriod(myHandle, Timer_PERIOD_US, morseCodeTiming.messageGap);
            currentState = IDLE;
            break;
        case IDLE:
            if(changeMessage){
                currentPattern = (currentPattern == sos) ? ok : sos;
                symbolIndex = 0;
            }
            else{
                symbolIndex = 0;
                if (symbol == '.') currentState = DOT;
                else if (symbol == '-') currentState = DASH;
            }
        default:
            currentState = IDLE;
            break;
    }

    Timer_start(myHandle); // Start timer with the new period for the next symbol or gap
}

void initTimer(void){
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if(timer0 == NULL){
        /* Failed to start timer */
        while(1){}
    }

    if(Timer_start(timer0) == Timer_STATUS_ERROR){
        /* Failed to start timer */
        while(1){}
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
        changeMessage = true;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
        changeMessage = true;
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1)
    {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    return (NULL);
}
